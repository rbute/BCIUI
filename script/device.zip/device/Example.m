global gLCApp;
global gChans;
%addpath device;
GetLCApp;
gChans = [ 1 ];
doc1=gLCApp.ActiveDocument;
RegisterLCEvents(doc1);
doc1.StartSampling();
pause(1)
doc1.StopSampling();