%%% Demo: L1-regularized Multiway CCA for SSVEP Recognition %%%
% by Yu Zhang, ECUST, 2014.4.29
% Email: zhangyu0112@gmail.com

clc;
clear all;
close all;


%% Load data
load SSVEPdata;
% 8 channels x 1000 points x 20 trials x 4 frequencies


%% Initialization
method={'CCA','L1MCCA'};
n_meth=length(method);
Fs=250;                                  % sampling rate
H=2;                                     % number of harmonics for reference construction
t_length=4;                              % analysis window length (s)
TW=0.5:0.5:t_length;
TW_p=round(TW*Fs);
n_run=20;                                % number of experimental runs
sti_f=[9.75 8.75 7.75 5.75];             % stimulus frequencies
n_sti=length(sti_f);                     % number of stimulus frequencies

% References signal with sine-cosine waveforms
sc1=refsig(sti_f(1),Fs,t_length*Fs,H);
sc2=refsig(sti_f(2),Fs,t_length*Fs,H);
sc3=refsig(sti_f(3),Fs,t_length*Fs,H);
sc4=refsig(sti_f(4),Fs,t_length*Fs,H);


%% SSVEP recognition
n_correct=zeros(length(TW),n_meth);
for cros=1:n_run                                  % leave-one-run-out cross-validation
    idx_testdata=cros;
    idx_traindata=1:n_run;
    idx_traindata(idx_testdata)=[];
    for mth=1:n_meth
        for tw_length=1:length(TW)
            switch method{mth}
                case 'CCA'
                    fprintf('CCA Processing TW %fs, No.crossvalidation %d \n',TW(tw_length),cros);
                    % recognize SSVEP
                    for j=1:4
                        [wx1,wy1,r1]=cca(SSVEPdata(:,1:TW_p(tw_length),idx_testdata,j),sc1(:,1:TW_p(tw_length)));
                        [wx2,wy2,r2]=cca(SSVEPdata(:,1:TW_p(tw_length),idx_testdata,j),sc2(:,1:TW_p(tw_length)));
                        [wx3,wy3,r3]=cca(SSVEPdata(:,1:TW_p(tw_length),idx_testdata,j),sc3(:,1:TW_p(tw_length)));
                        [wx4,wy4,r4]=cca(SSVEPdata(:,1:TW_p(tw_length),idx_testdata,j),sc4(:,1:TW_p(tw_length)));
                        [v,idx]=max([max(r1),max(r2),max(r3),max(r4)]);
                        if idx==j
                            n_correct(tw_length,mth)=n_correct(tw_length,mth)+1;
                        end
                    end

                case 'L1MCCA'
                    fprintf('L1MCCA Processing TW %fs, No.crossvalidation %d \n',TW(tw_length),cros);
                    max_iter=200;   % the maximal number of iteration for running L1MCCA
                    n_comp=1;       % number of projection components for learning the reference signals
                    lambda=0.02;    % regularization parameter for the 3rd-way (i.e., trial-way), which can be more precisely decided by cross-validation
                    iniw3=ones(length(idx_traindata),1);
                    % run L1MCCA to learn projections
                    [w11,w13,v11]=smcca(sc1(:,1:TW_p(tw_length)),SSVEPdata(:,1:TW_p(tw_length),idx_traindata,1),max_iter,iniw3,n_comp,lambda);
                    [w21,w23,v21]=smcca(sc2(:,1:TW_p(tw_length)),SSVEPdata(:,1:TW_p(tw_length),idx_traindata,2),max_iter,iniw3,n_comp,lambda);
                    [w31,w33,v31]=smcca(sc3(:,1:TW_p(tw_length)),SSVEPdata(:,1:TW_p(tw_length),idx_traindata,3),max_iter,iniw3,n_comp,lambda);
                    [w41,w43,v41]=smcca(sc4(:,1:TW_p(tw_length)),SSVEPdata(:,1:TW_p(tw_length),idx_traindata,4),max_iter,iniw3,n_comp,lambda);
                    % compute the optimal reference signals
                    % op_reference 1
                    op_refer1=ttm(tensor(SSVEPdata(:,1:TW_p(tw_length),idx_traindata,1)),w13',3);
                    op_refer1=tenmat(op_refer1,1);
                    op_refer1=op_refer1.data;
                    op_refer1=w11'*op_refer1;
                    % op_reference 2
                    op_refer2=ttm(tensor(SSVEPdata(:,1:TW_p(tw_length),idx_traindata,2)),w23',3);
                    op_refer2=tenmat(op_refer2,1);
                    op_refer2=op_refer2.data;
                    op_refer2=w21'*op_refer2;
                    % op_reference 3
                    op_refer3=ttm(tensor(SSVEPdata(:,1:TW_p(tw_length),idx_traindata,3)),w33',3);
                    op_refer3=tenmat(op_refer3,1);
                    op_refer3=op_refer3.data;
                    op_refer3=w31'*op_refer3;
                    % op_reference 4
                    op_refer4=ttm(tensor(SSVEPdata(:,1:TW_p(tw_length),idx_traindata,4)),w43',3);
                    op_refer4=tenmat(op_refer4,1);
                    op_refer4=op_refer4.data;
                    op_refer4=w41'*op_refer4;
                    % recognize SSVEP
                    for j=1:length(sti_f)
                        [wx1,wy1,r1]=cca(SSVEPdata(:,1:TW_p(tw_length),idx_testdata,j),op_refer1);
                        [wx2,wy2,r2]=cca(SSVEPdata(:,1:TW_p(tw_length),idx_testdata,j),op_refer2);
                        [wx3,wy3,r3]=cca(SSVEPdata(:,1:TW_p(tw_length),idx_testdata,j),op_refer3);
                        [wx4,wy4,r4]=cca(SSVEPdata(:,1:TW_p(tw_length),idx_testdata,j),op_refer4);
                        [v,idx]=max([max(r1),max(r2),max(r3),max(r4)]);
                        if idx==j
                            n_correct(tw_length,mth)=n_correct(tw_length,mth)+1;
                        end
                    end
            end
        end
    end
end


%% Plot results
accuracy=100*n_correct/n_sti/n_run;
color={'b-*','r-o'};
for mth=1:n_meth
    plot(TW,accuracy(:,mth),color{mth},'LineWidth',1);
    hold on;
end
xlabel('Time window (s)');
ylabel('Accuracy (%)');
xlim([0.25 4.25]);
set(gca,'xtick',0.5:0.5:4,'xticklabel',0.5:0.5:4);
ylim([30 100]);
title('\bf L1MCCA vs CCA for SSVEP Recognition');
grid;
h=legend(method);
set(h,'Location','SouthEast');

