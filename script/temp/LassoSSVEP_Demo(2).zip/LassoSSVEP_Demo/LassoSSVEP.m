%%% Lasso for SSVEP recognition %%%
% By Yu Zhang, 2014.8.7

clc;
clear all;
close all;


%% Initialization
method={'CCA','LASSO'};
n_meth=length(method);
Fs=250;                                  % sampling rate
N=2;                                     % number of harmonics
t_length=4;                              % analysis window length
TW=0.5:0.5:t_length;
TW_p=round(TW*Fs);
n_trial=20;                              % number of trials for each stimulus frequency
sti_f=[9.75 8.75 7.75 5.75];             % stimulus frequencies
n_sti=length(sti_f);                     % number of stimulus frequencies

% sine-cosine reference signals
sc1=SinCos(sti_f(1),Fs,t_length*Fs,N);
sc2=SinCos(sti_f(2),Fs,t_length*Fs,N);
sc3=SinCos(sti_f(3),Fs,t_length*Fs,N);
sc4=SinCos(sti_f(4),Fs,t_length*Fs,N);


%% Recognition
% Load data
filename={'SSVEPdata1','SSVEPdata2'};
% Each dataset is: 3 x 1000 x 20 x 4  (channels x points x trials x frequencies)
% channels are O1, Oz and O2
%
% Please note the LASSO method has been tested by using three channels O1 Oz and O2 only.
%
% For more detail, please see the paper:
% Y. Zhang, J. Jin, X. Qing, B. Wang, X. Wang. LASSO based stimulus frequency recognition model for SSVEP BCIs. 
% Biomedical Signal Processing and Control, vol. 7, no. 4, pp. 104-111, 2012.
% 

% Do recognition
n_sub=length(filename);
n_correct=zeros(n_sub,length(TW),n_meth);
for sub=1:n_sub
    load([filename{sub},'.mat']);
    n_ch=size(SSVEPdata,1);
    for cros=1:n_trial
        for mth=1:n_meth
            for tw_length=1:length(TW)
                switch method{mth}
                    case 'CCA'
                        fprintf('CCA Processing %s, TW %fs, No.trial %d \n',filename{sub},TW(tw_length),cros);
                        for j=1:length(sti_f)
                            [wx1,wy1,r1]=canoncorr(SSVEPdata(:,1:TW_p(tw_length),cros,j)',sc1(:,1:TW_p(tw_length))');
                            [wx2,wy2,r2]=canoncorr(SSVEPdata(:,1:TW_p(tw_length),cros,j)',sc2(:,1:TW_p(tw_length))');
                            [wx3,wy3,r3]=canoncorr(SSVEPdata(:,1:TW_p(tw_length),cros,j)',sc3(:,1:TW_p(tw_length))');
                            [wx4,wy4,r4]=canoncorr(SSVEPdata(:,1:TW_p(tw_length),cros,j)',sc4(:,1:TW_p(tw_length))');
                            [v,idx]=max([max(r1),max(r2),max(r3),max(r4)]);
                            if idx==j
                                n_correct(sub,tw_length,mth)=n_correct(sub,tw_length,mth)+1;
                            end
                        end
                    case 'LASSO'
                        fprintf('LASSO Processing %s, TW %fs, No.trial %d \n',filename{sub},TW(tw_length),cros);
                        lambda=0.1;     % sparse regularization parameter for Lasso
                        template=[sc1(:,1:TW_p(tw_length))',sc2(:,1:TW_p(tw_length))',sc3(:,1:TW_p(tw_length))',sc4(:,1:TW_p(tw_length))'];
                        for j=1:length(sti_f)
                            w=[];
                            for ch=1:n_ch
                                w(:,ch)=lasso(template,SSVEPdata(ch,1:TW_p(tw_length),cros,j)','lambda',lambda);
                            end
                            w=mean(abs(w),2);
                            b1=sum(w(1:2*N));b2=sum(w(2*N+1:4*N));b3=sum(w(4*N+1:6*N));b4=sum(w(6*N+1:8*N));
                            [v,idx]=max([b1,b2,b3,b4]);
                            if idx==j
                                n_correct(sub,tw_length,mth)=n_correct(sub,tw_length,mth)+1;
                            end
                        end
                end
            end
        end
    end
end


%% Plot results
accuracy=100*n_correct/n_sti/n_trial;
Maccuracy=mean(permute(accuracy,[3 2 1]),3);
color={'b-d','r-o'};
for sub=1:n_sub+1
    subplot(1,n_sub+1,sub);
    if sub==n_sub+1
        for mth=1:n_meth
            plot(TW,Maccuracy(mth,:),color{mth},'LineWidth',1);
            hold on;
        end
        title('Average');
    else
        for mth=1:n_meth
            plot(TW,accuracy(sub,:,mth),color{mth},'LineWidth',1);
            hold on;
        end
        title(filename{sub});
    end
    xlim([0.25 4.25]);
    ylim([0 100]);
    set(gca,'xtick',1:1:4,'xticklabel',1:1:4);
    set(gca,'ytick',0:10:100,'yticklabel',0:10:100);
    xlabel('Time Window (s)');
    if sub==1
        ylabel('Accuracy (%)');
    end
    grid;
end
legend(method,'location','southeast');

